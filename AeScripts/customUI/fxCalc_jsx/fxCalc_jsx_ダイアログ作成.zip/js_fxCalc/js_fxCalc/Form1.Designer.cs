﻿namespace js_fxCalc
{
	partial class fxCalcPanel
	{
		/// <summary>
		/// 必要なデザイナー変数です。
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// 使用中のリソースをすべてクリーンアップします。
		/// </summary>
		/// <param name="disposing">マネージ リソースが破棄される場合 true、破棄されない場合は false です。</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows フォーム デザイナーで生成されたコード

		/// <summary>
		/// デザイナー サポートに必要なメソッドです。このメソッドの内容を
		/// コード エディターで変更しないでください。
		/// </summary>
		private void InitializeComponent()
		{
			this.lbInput = new System.Windows.Forms.Label();
			this.btnMC = new System.Windows.Forms.Button();
			this.lbFrameRate = new System.Windows.Forms.Label();
			this.tbFrameRate = new System.Windows.Forms.TextBox();
			this.btnMR = new System.Windows.Forms.Button();
			this.btnMEq = new System.Windows.Forms.Button();
			this.bntMpls = new System.Windows.Forms.Button();
			this.btnInput0 = new System.Windows.Forms.Button();
			this.btnInput1 = new System.Windows.Forms.Button();
			this.btnInput4 = new System.Windows.Forms.Button();
			this.btnInput7 = new System.Windows.Forms.Button();
			this.btnMinus = new System.Windows.Forms.Button();
			this.btnInput2 = new System.Windows.Forms.Button();
			this.btnInput5 = new System.Windows.Forms.Button();
			this.btnInput8 = new System.Windows.Forms.Button();
			this.btnDot = new System.Windows.Forms.Button();
			this.btnInput3 = new System.Windows.Forms.Button();
			this.btnInput6 = new System.Windows.Forms.Button();
			this.btnInput9 = new System.Windows.Forms.Button();
			this.btnAdd = new System.Windows.Forms.Button();
			this.btnSub = new System.Windows.Forms.Button();
			this.btnMult = new System.Windows.Forms.Button();
			this.btnDiv = new System.Windows.Forms.Button();
			this.btnEq = new System.Windows.Forms.Button();
			this.btnBS = new System.Windows.Forms.Button();
			this.btnCL = new System.Windows.Forms.Button();
			this.btnCA = new System.Windows.Forms.Button();
			this.lbMem = new System.Windows.Forms.Label();
			this.cbIsSecKoma = new System.Windows.Forms.CheckBox();
			this.lbResult = new System.Windows.Forms.Label();
			this.lbAction = new System.Windows.Forms.Label();
			this.btnMminus = new System.Windows.Forms.Button();
			this.aeScriptDialogExport1 = new bryful.AEScriptDialogExport();
			this.SuspendLayout();
			// 
			// lbInput
			// 
			this.lbInput.Location = new System.Drawing.Point(63, 30);
			this.lbInput.Name = "lbInput";
			this.lbInput.Size = new System.Drawing.Size(208, 21);
			this.lbInput.TabIndex = 1;
			this.lbInput.Text = "None Input";
			// 
			// btnMC
			// 
			this.btnMC.Location = new System.Drawing.Point(10, 55);
			this.btnMC.Name = "btnMC";
			this.btnMC.Size = new System.Drawing.Size(36, 32);
			this.btnMC.TabIndex = 2;
			this.btnMC.Text = "MC";
			this.btnMC.UseVisualStyleBackColor = true;
			// 
			// lbFrameRate
			// 
			this.lbFrameRate.Location = new System.Drawing.Point(115, 231);
			this.lbFrameRate.Name = "lbFrameRate";
			this.lbFrameRate.Size = new System.Drawing.Size(32, 12);
			this.lbFrameRate.TabIndex = 27;
			this.lbFrameRate.Text = "FPS";
			// 
			// tbFrameRate
			// 
			this.tbFrameRate.Location = new System.Drawing.Point(153, 227);
			this.tbFrameRate.Name = "tbFrameRate";
			this.tbFrameRate.Size = new System.Drawing.Size(27, 19);
			this.tbFrameRate.TabIndex = 28;
			this.tbFrameRate.Text = "24";
			// 
			// btnMR
			// 
			this.btnMR.Location = new System.Drawing.Point(10, 89);
			this.btnMR.Name = "btnMR";
			this.btnMR.Size = new System.Drawing.Size(36, 32);
			this.btnMR.TabIndex = 3;
			this.btnMR.Text = "MR";
			this.btnMR.UseVisualStyleBackColor = true;
			// 
			// btnMEq
			// 
			this.btnMEq.Location = new System.Drawing.Point(10, 122);
			this.btnMEq.Name = "btnMEq";
			this.btnMEq.Size = new System.Drawing.Size(36, 32);
			this.btnMEq.TabIndex = 4;
			this.btnMEq.Text = "M=";
			this.btnMEq.UseVisualStyleBackColor = true;
			// 
			// bntMpls
			// 
			this.bntMpls.Location = new System.Drawing.Point(10, 156);
			this.bntMpls.Name = "bntMpls";
			this.bntMpls.Size = new System.Drawing.Size(36, 32);
			this.bntMpls.TabIndex = 5;
			this.bntMpls.Text = "M+";
			this.bntMpls.UseVisualStyleBackColor = true;
			// 
			// btnInput0
			// 
			this.btnInput0.Location = new System.Drawing.Point(52, 180);
			this.btnInput0.Name = "btnInput0";
			this.btnInput0.Size = new System.Drawing.Size(36, 36);
			this.btnInput0.TabIndex = 6;
			this.btnInput0.Text = "0";
			this.btnInput0.UseVisualStyleBackColor = true;
			// 
			// btnInput1
			// 
			this.btnInput1.Location = new System.Drawing.Point(52, 138);
			this.btnInput1.Name = "btnInput1";
			this.btnInput1.Size = new System.Drawing.Size(36, 36);
			this.btnInput1.TabIndex = 7;
			this.btnInput1.Text = "1";
			this.btnInput1.UseVisualStyleBackColor = true;
			// 
			// btnInput4
			// 
			this.btnInput4.Location = new System.Drawing.Point(52, 96);
			this.btnInput4.Name = "btnInput4";
			this.btnInput4.Size = new System.Drawing.Size(36, 36);
			this.btnInput4.TabIndex = 10;
			this.btnInput4.Text = "4";
			this.btnInput4.UseVisualStyleBackColor = true;
			// 
			// btnInput7
			// 
			this.btnInput7.Location = new System.Drawing.Point(52, 54);
			this.btnInput7.Name = "btnInput7";
			this.btnInput7.Size = new System.Drawing.Size(36, 36);
			this.btnInput7.TabIndex = 13;
			this.btnInput7.Text = "7";
			this.btnInput7.UseVisualStyleBackColor = true;
			// 
			// btnMinus
			// 
			this.btnMinus.Location = new System.Drawing.Point(94, 180);
			this.btnMinus.Name = "btnMinus";
			this.btnMinus.Size = new System.Drawing.Size(36, 36);
			this.btnMinus.TabIndex = 16;
			this.btnMinus.Text = "+/-";
			this.btnMinus.UseVisualStyleBackColor = true;
			// 
			// btnInput2
			// 
			this.btnInput2.Location = new System.Drawing.Point(94, 138);
			this.btnInput2.Name = "btnInput2";
			this.btnInput2.Size = new System.Drawing.Size(36, 36);
			this.btnInput2.TabIndex = 8;
			this.btnInput2.Text = "2";
			this.btnInput2.UseVisualStyleBackColor = true;
			// 
			// btnInput5
			// 
			this.btnInput5.Location = new System.Drawing.Point(94, 96);
			this.btnInput5.Name = "btnInput5";
			this.btnInput5.Size = new System.Drawing.Size(36, 36);
			this.btnInput5.TabIndex = 11;
			this.btnInput5.Text = "5";
			this.btnInput5.UseVisualStyleBackColor = true;
			// 
			// btnInput8
			// 
			this.btnInput8.Location = new System.Drawing.Point(94, 54);
			this.btnInput8.Name = "btnInput8";
			this.btnInput8.Size = new System.Drawing.Size(36, 36);
			this.btnInput8.TabIndex = 14;
			this.btnInput8.Text = "8";
			this.btnInput8.UseVisualStyleBackColor = true;
			// 
			// btnDot
			// 
			this.btnDot.Location = new System.Drawing.Point(136, 180);
			this.btnDot.Name = "btnDot";
			this.btnDot.Size = new System.Drawing.Size(36, 36);
			this.btnDot.TabIndex = 17;
			this.btnDot.Text = ".";
			this.btnDot.UseVisualStyleBackColor = true;
			// 
			// btnInput3
			// 
			this.btnInput3.Location = new System.Drawing.Point(136, 138);
			this.btnInput3.Name = "btnInput3";
			this.btnInput3.Size = new System.Drawing.Size(36, 36);
			this.btnInput3.TabIndex = 9;
			this.btnInput3.Text = "3";
			this.btnInput3.UseVisualStyleBackColor = true;
			// 
			// btnInput6
			// 
			this.btnInput6.Location = new System.Drawing.Point(136, 96);
			this.btnInput6.Name = "btnInput6";
			this.btnInput6.Size = new System.Drawing.Size(36, 36);
			this.btnInput6.TabIndex = 12;
			this.btnInput6.Text = "6";
			this.btnInput6.UseVisualStyleBackColor = true;
			// 
			// btnInput9
			// 
			this.btnInput9.Location = new System.Drawing.Point(136, 54);
			this.btnInput9.Name = "btnInput9";
			this.btnInput9.Size = new System.Drawing.Size(36, 36);
			this.btnInput9.TabIndex = 15;
			this.btnInput9.Text = "9";
			this.btnInput9.UseVisualStyleBackColor = true;
			// 
			// btnAdd
			// 
			this.btnAdd.Location = new System.Drawing.Point(193, 180);
			this.btnAdd.Name = "btnAdd";
			this.btnAdd.Size = new System.Drawing.Size(36, 36);
			this.btnAdd.TabIndex = 18;
			this.btnAdd.Text = "＋";
			this.btnAdd.UseVisualStyleBackColor = true;
			// 
			// btnSub
			// 
			this.btnSub.Location = new System.Drawing.Point(193, 138);
			this.btnSub.Name = "btnSub";
			this.btnSub.Size = new System.Drawing.Size(36, 36);
			this.btnSub.TabIndex = 19;
			this.btnSub.Text = "－";
			this.btnSub.UseVisualStyleBackColor = true;
			// 
			// btnMult
			// 
			this.btnMult.Location = new System.Drawing.Point(193, 96);
			this.btnMult.Name = "btnMult";
			this.btnMult.Size = new System.Drawing.Size(36, 36);
			this.btnMult.TabIndex = 20;
			this.btnMult.Text = "×";
			this.btnMult.UseVisualStyleBackColor = true;
			// 
			// btnDiv
			// 
			this.btnDiv.Location = new System.Drawing.Point(193, 54);
			this.btnDiv.Name = "btnDiv";
			this.btnDiv.Size = new System.Drawing.Size(36, 36);
			this.btnDiv.TabIndex = 21;
			this.btnDiv.Text = "÷";
			this.btnDiv.UseVisualStyleBackColor = true;
			// 
			// btnEq
			// 
			this.btnEq.Location = new System.Drawing.Point(235, 180);
			this.btnEq.Name = "btnEq";
			this.btnEq.Size = new System.Drawing.Size(36, 36);
			this.btnEq.TabIndex = 22;
			this.btnEq.Text = "＝";
			this.btnEq.UseVisualStyleBackColor = true;
			// 
			// btnBS
			// 
			this.btnBS.Location = new System.Drawing.Point(235, 138);
			this.btnBS.Name = "btnBS";
			this.btnBS.Size = new System.Drawing.Size(36, 36);
			this.btnBS.TabIndex = 23;
			this.btnBS.Text = "BS";
			this.btnBS.UseVisualStyleBackColor = true;
			// 
			// btnCL
			// 
			this.btnCL.Location = new System.Drawing.Point(235, 96);
			this.btnCL.Name = "btnCL";
			this.btnCL.Size = new System.Drawing.Size(36, 36);
			this.btnCL.TabIndex = 24;
			this.btnCL.Text = "C";
			this.btnCL.UseVisualStyleBackColor = true;
			// 
			// btnCA
			// 
			this.btnCA.Location = new System.Drawing.Point(235, 54);
			this.btnCA.Name = "btnCA";
			this.btnCA.Size = new System.Drawing.Size(36, 36);
			this.btnCA.TabIndex = 25;
			this.btnCA.Text = "CA";
			this.btnCA.UseVisualStyleBackColor = true;
			// 
			// lbMem
			// 
			this.lbMem.Location = new System.Drawing.Point(8, 228);
			this.lbMem.Name = "lbMem";
			this.lbMem.Size = new System.Drawing.Size(74, 15);
			this.lbMem.TabIndex = 26;
			this.lbMem.Text = "None Mem";
			// 
			// cbIsSecKoma
			// 
			this.cbIsSecKoma.AutoSize = true;
			this.cbIsSecKoma.Checked = true;
			this.cbIsSecKoma.CheckState = System.Windows.Forms.CheckState.Checked;
			this.cbIsSecKoma.Location = new System.Drawing.Point(186, 230);
			this.cbIsSecKoma.Name = "cbIsSecKoma";
			this.cbIsSecKoma.Size = new System.Drawing.Size(82, 16);
			this.cbIsSecKoma.TabIndex = 30;
			this.cbIsSecKoma.Text = "SS+FF形式";
			this.cbIsSecKoma.UseVisualStyleBackColor = true;
			// 
			// lbResult
			// 
			this.lbResult.Location = new System.Drawing.Point(63, 9);
			this.lbResult.Name = "lbResult";
			this.lbResult.Size = new System.Drawing.Size(208, 21);
			this.lbResult.TabIndex = 31;
			this.lbResult.Text = "None Input";
			// 
			// lbAction
			// 
			this.lbAction.Location = new System.Drawing.Point(8, 30);
			this.lbAction.Name = "lbAction";
			this.lbAction.Size = new System.Drawing.Size(49, 21);
			this.lbAction.TabIndex = 32;
			this.lbAction.Text = "＝";
			// 
			// btnMminus
			// 
			this.btnMminus.Location = new System.Drawing.Point(10, 189);
			this.btnMminus.Name = "btnMminus";
			this.btnMminus.Size = new System.Drawing.Size(36, 32);
			this.btnMminus.TabIndex = 33;
			this.btnMminus.Text = "M+";
			this.btnMminus.UseVisualStyleBackColor = true;
			// 
			// aeScriptDialogExport1
			// 
			this.aeScriptDialogExport1.Form = this;
			this.aeScriptDialogExport1.IsDialog = false;
			// 
			// fxCalcPanel
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(277, 253);
			this.Controls.Add(this.btnMminus);
			this.Controls.Add(this.lbAction);
			this.Controls.Add(this.lbResult);
			this.Controls.Add(this.cbIsSecKoma);
			this.Controls.Add(this.lbMem);
			this.Controls.Add(this.btnEq);
			this.Controls.Add(this.btnBS);
			this.Controls.Add(this.btnCL);
			this.Controls.Add(this.btnCA);
			this.Controls.Add(this.btnAdd);
			this.Controls.Add(this.btnSub);
			this.Controls.Add(this.btnMult);
			this.Controls.Add(this.btnDiv);
			this.Controls.Add(this.btnDot);
			this.Controls.Add(this.btnInput3);
			this.Controls.Add(this.btnInput6);
			this.Controls.Add(this.btnInput9);
			this.Controls.Add(this.btnMinus);
			this.Controls.Add(this.btnInput2);
			this.Controls.Add(this.btnInput5);
			this.Controls.Add(this.btnInput8);
			this.Controls.Add(this.btnInput0);
			this.Controls.Add(this.btnInput1);
			this.Controls.Add(this.btnInput4);
			this.Controls.Add(this.btnInput7);
			this.Controls.Add(this.bntMpls);
			this.Controls.Add(this.btnMEq);
			this.Controls.Add(this.btnMR);
			this.Controls.Add(this.tbFrameRate);
			this.Controls.Add(this.lbFrameRate);
			this.Controls.Add(this.btnMC);
			this.Controls.Add(this.lbInput);
			this.Name = "fxCalcPanel";
			this.Text = "fxCalc";
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.Label lbInput;
		private System.Windows.Forms.Button btnMC;
		private System.Windows.Forms.Label lbFrameRate;
		private System.Windows.Forms.TextBox tbFrameRate;
		private System.Windows.Forms.Button btnMR;
		private System.Windows.Forms.Button btnMEq;
		private System.Windows.Forms.Button bntMpls;
		private System.Windows.Forms.Button btnInput0;
		private System.Windows.Forms.Button btnInput1;
		private System.Windows.Forms.Button btnInput4;
		private System.Windows.Forms.Button btnInput7;
		private System.Windows.Forms.Button btnMinus;
		private System.Windows.Forms.Button btnInput2;
		private System.Windows.Forms.Button btnInput5;
		private System.Windows.Forms.Button btnInput8;
		private System.Windows.Forms.Button btnDot;
		private System.Windows.Forms.Button btnInput3;
		private System.Windows.Forms.Button btnInput6;
		private System.Windows.Forms.Button btnInput9;
		private System.Windows.Forms.Button btnAdd;
		private System.Windows.Forms.Button btnSub;
		private System.Windows.Forms.Button btnMult;
		private System.Windows.Forms.Button btnDiv;
		private System.Windows.Forms.Button btnEq;
		private System.Windows.Forms.Button btnBS;
		private System.Windows.Forms.Button btnCL;
		private System.Windows.Forms.Button btnCA;
		private System.Windows.Forms.Label lbMem;
		private bryful.AEScriptDialogExport aeScriptDialogExport1;
		private System.Windows.Forms.CheckBox cbIsSecKoma;
		private System.Windows.Forms.Label lbAction;
		private System.Windows.Forms.Label lbResult;
		private System.Windows.Forms.Button btnMminus;

	}
}

