﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace bryful
{
    public class AEScriptDialogExport : Component
    {
        private Form _Form;
        private ContextMenuStrip cm = new ContextMenuStrip();
        private ToolStripMenuItem toClipMenu = new ToolStripMenuItem();
        private ToolStripMenuItem saveAsMenu = new ToolStripMenuItem();
        private ToolStripMenuItem showCodeMenu = new ToolStripMenuItem();
        private ToolStripMenuItem isDialogMenu = new ToolStripMenuItem();
        
        private bool _IsDialog = true;


		private List<string> lines = new List<string>();

		private string _Result = "";

 
		private const string MainCodePalette =
		  "function $WinObjName(me)\n"
			+ "{"
			+ "\t//---------------\n"
			+ "\tthis.winObj = ( me instanceof Panel) ? me : new Window($WinObjParams);\n"
			+ "$build\n"
			+ "\t//---------------\n"
			+ "\tif ( ( me instanceof Panel) == false){ this.winObj.center(); this.winObj.show(); }\n"
			+ "}\n"
			+ "var dlg = new $WinObjName(this);\n"
			+ "\n";

		private const string MainCodeWindow =
			  "function $WinObjName()\n"
			+ "{"

			+ "\t//---------------\n"
			+ "\tthis.winObj = new Window($WinObjParams);"
			+ "$build\n"
			+ "\t//---------------\n"
			+ "\tthis.show = function()\n"
			+ "\t{\n"
			+ "\t\treturn this.winObj.show();\n"
			+ "\t}\n"
			+ "\t//---------------\n"
			+ "}\n"
			+ "var dlg = new $WinObjName;\n"
			+ "dlg.show();\n"
			+ "\n";

        //------------------------------------------------------------------------------------------------------------
        public AEScriptDialogExport()
        {
            cm.Opened += new System.EventHandler(isDialogMenu_Opened);
            toClipMenu.Text = "To Clipboard";
            toClipMenu.Click += new EventHandler(toClipMenu_Click);
            saveAsMenu.Text = "Show SaveDialog";
            saveAsMenu.Click += new EventHandler(saveAsMenu_Click);
            showCodeMenu.Text = "Show Code And ToClipboard";
            showCodeMenu.Click += new EventHandler(showCodeMenu_Click);

            isDialogMenu.Text = "for Dialog";
            isDialogMenu.Click += new EventHandler(isDialogMenu_Click);
            isDialogMenu.Checked = _IsDialog;


            cm.Items.Add(toClipMenu);
            cm.Items.Add(saveAsMenu);
            cm.Items.Add(showCodeMenu);
            cm.Items.Add(new ToolStripSeparator());
            cm.Items.Add(isDialogMenu);

        }

        //------------------------------------------------------------------------------------------------------------
        private void SetupMenu()
        {
        }
        //------------------------------------------------------------------------------------------------------------
        private void isDialogMenu_Opened(object sender, EventArgs e)
        {
            isDialogMenu.Checked = _IsDialog;
        }
        //------------------------------------------------------------------------------------------------------------
        private void isDialogMenu_Click(object sender, EventArgs e)
        {
            _IsDialog = !_IsDialog;
        }
        //------------------------------------------------------------------------------------------------------------
        private void toClipMenu_Click(object sender, EventArgs e)
        {
            ToClipboard();
            if (_Result != string.Empty)
            {
                MessageBox.Show("to clipboard !");
            }
            else
            {
                MessageBox.Show("error!!");
            }
        }
        //------------------------------------------------------------------------------------------------------------
        private void showCodeMenu_Click(object sender, EventArgs e)
        {
            ToClipboard();
            MessageBox.Show(_Result);
 
        }
        //------------------------------------------------------------------------------------------------------------
        private void saveAsMenu_Click(object sender, EventArgs e)
        {
            SaveAs();
        }
        //------------------------------------------------------------------------------------------------------------
        public Form Form
        {
            get { return _Form; }
            set
            {
                _Form = value;
                if (_Form != null)
                {
                    _Form.ContextMenuStrip = cm; 
                }
            }
        }
        //------------------------------------------------------------------------------------------------------------
		private string RectToBounds(Rectangle rct)
        {
			string ret = "";
			ret += "[" + rct.Left.ToString() + ", " + rct.Top.ToString() + ", " + rct.Left.ToString() +"+"+ rct.Width.ToString() + ", " + rct.Top.ToString() +"+"+ rct.Height.ToString() + "]";
			return ret;
        }
        //------------------------------------------------------------------------------------------------------------
        private string AddButton(string parentName, Button btn)
        {
            string ret = "";

            ret += "this." + btn.Name + " = ";
            ret += parentName + ".add(\"button\", ";
            ret += RectToBounds(btn.Bounds) +", ";
            ret += "\""+ btn.Text+"\"";

			if ( (btn.DialogResult == DialogResult.OK) || (btn.DialogResult == DialogResult.Yes))
			{
				ret += ", {name:'ok'}";
			}
			if ((btn.DialogResult == DialogResult.Cancel) || (btn.DialogResult == DialogResult.No))
			{
				ret += ", {name:'cancel'}";
			}
			ret += ");";
            return ret;
        }
        //------------------------------------------------------------------------------------------------------------
        private string AddStaticText(string parentName, Label item)
        {
            string ret = "";

            ret += "this."+item.Name + " = ";
			ret += parentName + ".add(\"statictext\", ";
			ret += RectToBounds(item.Bounds) + ", ";
			ret += "\"" + item.Text + "\" );";
            return ret;
        }
        //------------------------------------------------------------------------------------------------------------
        private string AddProgressbar(string parentName, ProgressBar item)
        {
            string ret = "";

            ret += "this." + item.Name + " = ";
            ret += parentName + ".add(\"progressbar\", ";
            ret += RectToBounds(item.Bounds) + ", ";
            ret += item.Value.ToString() + "," + item.Maximum.ToString()+" );";
            return ret;
        }
        //------------------------------------------------------------------------------------------------------------
		private string AddEdittext(string parentName, TextBox item)
		{
			string ret = "";

			ret += "this." + item.Name + " = ";
			ret += parentName + ".add(\"edittext\", ";
			ret += RectToBounds(item.Bounds) + ", ";
			ret += "\"" + item.Text + "\" );";
			return ret;
		}
        //------------------------------------------------------------------------------------------------------------
        private string AddRadiobutton(string parentName, RadioButton item)
        {
            string ret = "";

            ret += "this." + item.Name + " = ";
            ret += parentName + ".add(\"radiobutton\", ";
            ret += RectToBounds(item.Bounds) + ", ";
            ret += "\"" + item.Text + "\" );";
            return ret;
        }
        //------------------------------------------------------------------------------------------------------------
		private string AddPanel(string parentName, GroupBox item)
		{
			string ret = "";

			ret += "this." + item.Name + " = ";
			ret += parentName + ".add(\"panel\", ";
			ret += RectToBounds(item.Bounds) + ", ";
			ret += "\"" + item.Text + "\" );";
			return ret;
		}
		//------------------------------------------------------------------------------------------------------------
		private string AddGroup(string parentName, Panel item)
		{
			string ret = "";

			ret += "this." + item.Name + " = ";
			ret += parentName + ".add(\"group\", ";
			ret += RectToBounds(item.Bounds) + ", ";
			ret += "\"" + item.Text + "\" );";


			return ret;
		}
		//------------------------------------------------------------------------------------------------------------
		private string AddCheckBox(string parentName, CheckBox item)
		{
			string ret = "";

			ret += "this." + item.Name + " = ";
			ret += parentName + ".add(\"checkbox\", ";
			ret += RectToBounds(item.Bounds) + ", ";



			ret += "\"" + item.Text + "\" );";
            if (item.Checked == true)
            {
                ret += " this." + item.Name + ".value = true;"; 
            }

            
            return ret;
		}
        //------------------------------------------------------------------------------------------------------------
        private string AddHscrollbar(string parentName, HScrollBar item)
        {
            string ret = "";

            ret += "this." + item.Name + " = ";
            ret += parentName + ".add(\"scrollbar\", ";
            ret += RectToBounds(item.Bounds) + ", ";
            ret += item.Value.ToString() + ", " + item.Minimum.ToString() + ", " + item.Maximum.ToString() + " );";
            return ret;
        }
        //------------------------------------------------------------------------------------------------------------
        private string AddVscrollbar(string parentName, VScrollBar item)
        {
            string ret = "";

            ret += "this." + item.Name + " = ";
            ret += parentName + ".add(\"scrollbar\", ";
            ret += RectToBounds(item.Bounds) + ", ";
            ret += item.Value.ToString() + ", " + item.Minimum.ToString() + ", " + item.Maximum.ToString() + " );";
            return ret;
        }
        //------------------------------------------------------------------------------------------------------------
        private string AddSlider(string parentName, TrackBar item)
        {
            string ret = "";

            ret += "this." + item.Name + " = ";
            ret += parentName + ".add(\"slider\", ";
            ret += RectToBounds(item.Bounds) + ", ";
            ret += item.Value.ToString() + ", " + item.Minimum.ToString() + ", " + item.Maximum.ToString() + " );";
            return ret;
        }
        //------------------------------------------------------------------------------------------------------------
        private string AddImage(string parentName, PictureBox item)
        {
            string ret = "";

            string s = item.Name +"_image";
            ret += "/* var " + s + " = new File(\"./適当な画像ファイル.png\"); */"; 
            ret += "this." + item.Name + " = ";
            ret += parentName + ".add(\"image\", ";
            ret += RectToBounds(item.Bounds);
            ret += "/*  ," + s  +"*/ );";
            return ret;
        }
        //------------------------------------------------------------------------------------------------------------
        private string AddIconbutton(string parentName, bryful.iconbutton item)
        {
            string ret = "";

            string s = item.Name + "_image";
            ret += "/* var " + s + " = new File(\"./適当な画像ファイル.png\"); */";
            ret += "this." + item.Name + " = ";
            ret += parentName + ".add(\"iconbutton\", ";
            ret += RectToBounds(item.Bounds);
            ret += "/*  ," + s + ",{ button:true,toolbutton:true }*/ );";
            return ret;
        }
        //------------------------------------------------------------------------------------------------------------
        private string AddIconbutton(string parentName, PictureBox item)
        {
            string ret = "";

            string s = item.Name + "_image";
            ret += "/* var " + s + " = new File(\"./適当な画像ファイル.png\"); */";
            ret += "this." + item.Name + " = ";
            ret += parentName + ".add(\"image\", ";
            ret += RectToBounds(item.Bounds);
            ret += "/*  ," + s + "*/ );";
            return ret;
        }
        //------------------------------------------------------------------------------------------------------------
		private string AddDropdownlist(string parentName, ComboBox item)
		{
			string ret = "";

			ret += "this." + item.Name + " = ";
			ret += parentName + ".add(\"dropdownlist\", ";
			ret += RectToBounds(item.Bounds) + ", ";
			string s = "[";
			if (item.Items.Count > 0)
			{
				for (int i = 0; i < item.Items.Count; i++)
				{
					s += "\"" + item.Items[i].ToString() + "\"";
					if (i < item.Items.Count - 1) s += ",";
				}
			}
			s += " ]";
			ret += s;
			ret +=  " );";
			return ret;
		}
		//------------------------------------------------------------------------------------------------------------
		private string AddListbox(string parentName, ListBox item)
		{
			string ret = "";

			ret += "this." + item.Name + " = ";
			ret += parentName + ".add(\"listbox\", ";
			ret += RectToBounds(item.Bounds) + ", ";
			string s = "[";
			if (item.Items.Count > 0)
			{
				for (int i = 0; i < item.Items.Count; i++)
				{
					s += "\"" + item.Items[i].ToString() + "\"";
					if (i < item.Items.Count - 1) s += ",";
				}
			}
			s += " ]";
			ret += s;
			ret += " );";
			return ret;
		}
		//------------------------------------------------------------------------------------------------------------
        private void ListupControls( string parentName, System.Windows.Forms.Control.ControlCollection ctrls)
        {
            if (ctrls.Count <= 0) return;
			int TabMax = 0;
			for (int i = 0; i < ctrls.Count; i++)
			{
				if (ctrls[i].TabIndex > TabMax) TabMax = ctrls[i].TabIndex; 
			}

			//タブ順に探していく
			for (int k = 0; k <= TabMax; k++)
			{

				//Addされてるので、後ろから読み込み
				for (int i = ctrls.Count - 1; i >= 0; i--)
				{
					//タブのIndexが同じなら実行
					if (ctrls[i].TabIndex == k)
					{
						if (ctrls[i] is Button)
						{
							lines.Add(AddButton(parentName, (Button)ctrls[i]));
						}
						else if (ctrls[i] is Label)
						{
							lines.Add(AddStaticText(parentName, (Label)ctrls[i]));
						}
						else if (ctrls[i] is TextBox)
						{
							lines.Add(AddEdittext(parentName, (TextBox)ctrls[i]));
						}
						else if (ctrls[i] is CheckBox)
						{
							lines.Add(AddCheckBox(parentName, (CheckBox)ctrls[i]));
						}
                        else if (ctrls[i] is RadioButton)
                        {
                            lines.Add(AddRadiobutton(parentName, (RadioButton)ctrls[i]));
                        }
                        else if (ctrls[i] is HScrollBar)
                        {
                            lines.Add(AddHscrollbar(parentName, (HScrollBar)ctrls[i]));
                        }
                        else if (ctrls[i] is VScrollBar)
                        {
                            lines.Add(AddVscrollbar(parentName, (VScrollBar)ctrls[i]));
                        }
                        else if (ctrls[i] is TrackBar)
                        {
                            lines.Add(AddSlider(parentName, (TrackBar)ctrls[i]));
                        }
                        else if (ctrls[i] is ComboBox)
						{
							lines.Add(AddDropdownlist(parentName, (ComboBox)ctrls[i]));
						}
						else if (ctrls[i] is ListBox)
						{
							lines.Add(AddListbox(parentName, (ListBox)ctrls[i]));
						}
                        else if (ctrls[i] is ProgressBar)
                        {
                            lines.Add(AddProgressbar(parentName, (ProgressBar)ctrls[i]));
                        }
                        else if (ctrls[i] is bryful.iconbutton)
                        {
                            lines.Add(AddIconbutton(parentName, (bryful.iconbutton)ctrls[i]));
                        }
                        else if (ctrls[i] is PictureBox)
                        {
                            lines.Add(AddImage(parentName, (PictureBox)ctrls[i]));
                        }
                        else if (ctrls[i] is GroupBox)
						{
							lines.Add(AddPanel(parentName, (GroupBox)ctrls[i]));
							ListupControls("this." + ctrls[i].Name, ctrls[i].Controls);
						}
						else if (ctrls[i] is Panel)
						{
							lines.Add(AddGroup(parentName, (Panel)ctrls[i]));
							ListupControls("this." + ctrls[i].Name, ctrls[i].Controls);
						}
					}
				}
			}
        }
        //------------------------------------------------------------------------------------------------------------
        private void Listup()
        {
            string ret = "";
			lines.Clear();
			_Result = "";
			if (_Form == null) return;
			if ( _Form.Controls.Count<=0) return;
			if (_IsDialog == true)
			{
				ret = MainCodeWindow;
			}
			else
			{
				ret = MainCodePalette;
			}

			ListupControls("this.winObj", _Form.Controls);
			string ctrl = "\n";
			for (int i = 0; i < lines.Count; i++)
			{
				ctrl += "\t"+lines[i] + "\n";
			}
			ret = ret.Replace("$build", ctrl);

			string winObjName = _Form.Name;
			ret = ret.Replace("$WinObjName", winObjName);

			Rectangle winBounds = new Rectangle(_Form.Left, _Form.Top, _Form.ClientSize.Width, _Form.ClientSize.Height);
			string WinObjParams = "";
			if (_IsDialog == true)
			{
				WinObjParams = "\"dialog\", ";
			}
			else
			{
				WinObjParams = "\"palette\", ";
			}
			WinObjParams += "\"" + _Form.Text + "\", ";
			WinObjParams += RectToBounds(winBounds);
			ret = ret.Replace("$WinObjParams", WinObjParams);
			
			_Result = ret;
          
        }
		//------------------------------------------------------------------------------------------------------------
		/// <summary>
		/// クリップボードへ
		/// </summary>
		public void ToClipboard()
		{
			Listup();
			if (_Result != string.Empty)
			{
				Clipboard.SetText(_Result);
			}
		}
		//------------------------------------------------------------------------------------------------------------
		/// <summary>
		/// ファイル名を指定して保存
		/// </summary>
		/// <param name="path"></param>
		/// <returns></returns>
		public bool SaveToFile(string path)
		{
			if (_Result == "") return false;
			System.IO.StreamWriter sw = new System.IO.StreamWriter(path, false, System.Text.Encoding.GetEncoding("utf-8"));
			try
			{
				//TextBox1.Textの内容を書き込む
				sw.Write(_Result);
			}
			catch
			{
				return false;
			}
			finally
			{
				sw.Close();
			}
			return true;
		}
		//------------------------------------------------------------------------------------------------------------
		/// <summary>
		/// ダイアログを表示してExport
		/// </summary>
		/// <returns></returns>
		public bool SaveAs()
		{
			Listup();
			if (_Result == string.Empty) return false;
			SaveFileDialog sv = new SaveFileDialog();
			sv.Title = "Export JavaScript Code";
			sv.Filter = "jsx(*.jsx)|*.jsx|txt(*.txt)|*.txt|all(*.*)|*.*";
			if (sv.ShowDialog() == DialogResult.OK)
			{
				return SaveToFile(sv.FileName);
			}
			else
			{
				return false;
			}
		}
		//------------------------------------------------------------------------------------------------------------
		public bool IsDialog
		{
			get { return _IsDialog; }
			set { _IsDialog = value; }
		}
		//------------------------------------------------------------------------------------------------------------
		public string Result
		{
			get { return _Result; }
		}
	}
}
